#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <postgresql/libpq-fe.h>

#define THRESHOLD 100000

PGconn *conn = NULL;

void do_exit(PGconn *conn)
{
	if (conn != NULL)
		PQfinish(conn);
    exit(EXIT_FAILURE);
}

/* Do a clean exit on receiving SIGTERM signal */
void sigterm_handler(int signal)
{
    if (conn != NULL)
        PQfinish(conn);
    printf("[DAEMON TERMINATED]\n");
    exit(EXIT_SUCCESS);
}

int main()
{
    signal(SIGTERM, sigterm_handler);
    PGresult *res_use_count, *res_rel_size;
    char query[512], *relname, *attname;
    int result_count, usecount;

    printf("[DAEMON STARTED]\n");

    /* Connect to database */
    conn = PQconnectdb("dbname=postgres host=localhost user=chiranmoy");
    if (PQstatus(conn) == CONNECTION_BAD)
    {
        fprintf(stderr, "Connection to database failed: %s\n", PQerrorMessage(conn));
        do_exit(conn);
    }

    while (1)
    {
    	/* Get tuples from pg_att_use_count */
        res_use_count = PQexec(conn, "SELECT * FROM pg_att_use_count;");

        if (PQresultStatus(res_use_count) != PGRES_TUPLES_OK)
            do_exit(conn);

        /* Number of tuples in the result */
        result_count = PQntuples(res_use_count);

        for (int row = 0; row < result_count; row++)
        {
            relname = PQgetvalue(res_use_count, row, 0);
            attname = PQgetvalue(res_use_count, row, 1);
            usecount = atoi(PQgetvalue(res_use_count, row, 2));

            memset(query, 0, sizeof(query));
			/* Get estimated relation size */
            sprintf(query, "SELECT reltuples FROM pg_class where relname='%s';", relname);
            res_rel_size = PQexec(conn, query);
            int relsize = atoi(PQgetvalue(res_rel_size, 0, 0));

//            printf("Relname: %s\tAttname: %s\tUse Count: %d\tRelsize: %d\n", relname, attname, usecount, relsize);

            /* if the relation size times use count crosses the threshold, create the index */
            if (usecount * relsize >= THRESHOLD)
            {
                memset(query, 0, sizeof(query));
                sprintf(query, "CREATE INDEX IF NOT EXISTS %s_%s ON %s(%s);", relname, attname, relname, attname);
                res_rel_size = PQexec(conn, query);
                /*
                 * Possible Improvement:
                 * 		1. Delete the tuple from pg_att_use_count
                 */
            }

            PQclear(res_rel_size);
        }

        PQclear(res_use_count);
        sleep(20);
    }

    do_exit(conn);

    return 0;
}
